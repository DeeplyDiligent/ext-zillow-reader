import * as React from 'react';
import { Component } from 'react';

interface ContactsProps {
    
}
 
const Contacts: React.FunctionComponent<ContactsProps> = () => {
    return <>Contacts</>;
}
 
export default Contacts;